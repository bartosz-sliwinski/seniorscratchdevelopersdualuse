# Edytor stref lat/lon

Aplikacja React + Leaflet do ręcznego wyznaczania stref na mapie i eksportu danych do formatu:

```json
{
  "zones": [
    {
      "id": 1,
      "coords": [
        [
          [50.572216, 21.961828]
        ]
      ]
    }
  ]
}
```

## Uruchomienie

```bash
npm install
npm run dev
```

## Jak działa

- ustawiasz liczbę stref,
- wybierasz aktywną strefę,
- klikasz na mapie, aby dodawać punkty,
- po dodaniu minimum 3 punktów strefa rysuje się jako poligon,
- eksportujesz dane przyciskiem `Eksportuj JSON`.
