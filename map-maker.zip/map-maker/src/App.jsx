import { Fragment, useMemo, useState } from "react";
import { MapContainer, Marker, Polygon, Polyline, Popup, TileLayer, useMapEvents } from "react-leaflet";
import L from "leaflet";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

const INITIAL_CENTER = [50.572216, 21.961828];

const zoneColors = [
  "#d9480f",
  "#2b8a3e",
  "#1c7ed6",
  "#9c36b5",
  "#f08c00",
  "#0b7285",
  "#c2255c",
  "#5f3dc4"
];

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow
});

function createZone(id) {
  return {
    id,
    coords: []
  };
}

function normalizeZoneCount(value) {
  const parsed = Number.parseInt(value, 10);
  if (Number.isNaN(parsed) || parsed < 1) {
    return 1;
  }

  return parsed;
}

function MapClickHandler({ onMapClick }) {
  useMapEvents({
    click(event) {
      onMapClick(event.latlng);
    }
  });

  return null;
}

function App() {
  const [zones, setZones] = useState([createZone(1)]);
  const [activeZoneId, setActiveZoneId] = useState(1);

  const activeZone = zones.find((zone) => zone.id === activeZoneId) ?? zones[0];
  const exportPayload = useMemo(
    () => ({
      zones: zones.map((zone) => ({
        id: zone.id,
        coords: [
          zone.coords.map((coord) => [
            Number(coord.lat.toFixed(6)),
            Number(coord.lon.toFixed(6))
          ])
        ]
      }))
    }),
    [zones]
  );

  const handleZoneCountChange = (nextValue) => {
    const targetCount = normalizeZoneCount(nextValue);

    setZones((currentZones) => {
      const nextZones = currentZones.slice(0, targetCount);

      for (let id = nextZones.length + 1; id <= targetCount; id += 1) {
        nextZones.push(createZone(id));
      }

      return nextZones;
    });

    setActiveZoneId((currentActiveZoneId) => Math.min(currentActiveZoneId, targetCount));
  };

  const handleMapClick = ({ lat, lng }) => {
    setZones((currentZones) =>
      currentZones.map((zone) =>
        zone.id === activeZoneId
          ? {
              ...zone,
              coords: [...zone.coords, { lat, lon: lng }]
            }
          : zone
      )
    );
  };

  const removeLastPoint = () => {
    setZones((currentZones) =>
      currentZones.map((zone) =>
        zone.id === activeZoneId
          ? {
              ...zone,
              coords: zone.coords.slice(0, -1)
            }
          : zone
      )
    );
  };

  const clearActiveZone = () => {
    setZones((currentZones) =>
      currentZones.map((zone) =>
        zone.id === activeZoneId
          ? {
              ...zone,
              coords: []
            }
          : zone
      )
    );
  };

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = "zones.json";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="shell">
      <header className="hero threat-hero">
        <div>
          <p className="eyebrow">React + Leaflet</p>
          <h1>Edytor stref operacyjnych</h1>
        </div>
      </header>

      <main className="dashboard assessment-layout">
        <section className="panel upload-panel controls-panel">
          <div className="panel-kicker">Konfiguracja</div>
          <div className="panel-head">
            <h2>Sterowanie strefami</h2>
            <span className="status-chip">{zones.length} stref</span>
          </div>

          <p className="message">Kliknięcie na mapie dopisuje punkt do aktualnie zaznaczonej strefy.</p>

          <div className="form-grid">
            <label className="field field-wide">
              <span>Liczba stref</span>
              <input
                type="number"
                min="1"
                value={zones.length}
                onChange={(event) => handleZoneCountChange(event.target.value)}
              />
            </label>
          </div>

          <div className="zones-list">
            {zones.map((zone, index) => {
              const isActive = zone.id === activeZoneId;
              const color = zoneColors[index % zoneColors.length];

              return (
                <button
                  key={zone.id}
                  type="button"
                  className={`zone-card ${isActive ? "active" : ""}`}
                  onClick={() => setActiveZoneId(zone.id)}
                >
                  <span className="swatch" style={{ backgroundColor: color }} />
                  <span>Strefa {zone.id}</span>
                  <strong>{zone.coords.length} pkt</strong>
                </button>
              );
            })}
          </div>

          <div className="actions">
            <button type="button" onClick={removeLastPoint} disabled={!activeZone?.coords.length}>
              Usuń ostatni punkt
            </button>
            <button type="button" onClick={clearActiveZone} disabled={!activeZone?.coords.length}>
              Wyczyść strefę
            </button>
            <button type="button" onClick={downloadJson}>
              Eksportuj JSON
            </button>
          </div>
        </section>

        <section className="panel preview-panel">
          <div className="panel-kicker">Obszar roboczy</div>
          <div className="panel-head">
            <h2>Mapa interaktywna</h2>
            <span className="risk-badge">
              {activeZone?.coords.length ?? 0} punktów w strefie {activeZoneId}
            </span>
          </div>

          <div className="image-frame map-frame">
            <MapContainer center={INITIAL_CENTER} zoom={13} className="map" scrollWheelZoom>
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <MapClickHandler onMapClick={handleMapClick} />

              {zones.map((zone, index) => {
                const positions = zone.coords.map((coord) => [coord.lat, coord.lon]);
                const color = zoneColors[index % zoneColors.length];

                return (
                  <Fragment key={zone.id}>
                    {zone.coords.length >= 2 && zone.coords.length < 3 ? (
                      <Polyline
                        positions={positions}
                        pathOptions={{
                          color,
                          weight: zone.id === activeZoneId ? 3 : 2
                        }}
                      />
                    ) : null}

                    {zone.coords.length >= 3 ? (
                      <Polygon
                        positions={positions}
                        pathOptions={{
                          color,
                          fillColor: color,
                          fillOpacity: zone.id === activeZoneId ? 0.3 : 0.18,
                          weight: zone.id === activeZoneId ? 3 : 2
                        }}
                      />
                    ) : null}

                    {zone.coords.map((coord, pointIndex) => (
                      <Marker key={`${zone.id}-${pointIndex}`} position={[coord.lat, coord.lon]}>
                        <Popup>
                          Strefa {zone.id}, punkt {pointIndex + 1}
                          <br />
                          lat: {coord.lat.toFixed(6)}
                          <br />
                          lon: {coord.lon.toFixed(6)}
                        </Popup>
                      </Marker>
                    ))}
                  </Fragment>
                );
              })}
            </MapContainer>
          </div>
        </section>

        <section className="panel result-panel">
          <div className="panel-kicker">Eksport</div>
          <div className="panel-head">
            <h2>Podgląd JSON</h2>
            <span className="status-chip">{exportPayload.zones.length} rekordów</span>
          </div>
          <div className="analysis-copy">
            <pre>{JSON.stringify(exportPayload, null, 2)}</pre>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
