import os
os.environ["HF_HOME"] = r"D:\Dane\SpaceShield\llm-models"

from flask import Flask, request, jsonify
from transformers import Qwen2_5_VLForConditionalGeneration, AutoProcessor, BitsAndBytesConfig
from qwen_vl_utils import process_vision_info
from PIL import Image
import torch, json, io
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4"
)

print("Loading model in 4-bit...")
model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
    "Qwen/Qwen2.5-VL-3B-Instruct",
    quantization_config=bnb_config,
    device_map="auto"
)

model = model.eval()
torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True

processor = AutoProcessor.from_pretrained(
    "Qwen/Qwen2.5-VL-3B-Instruct",
    min_pixels=256*28*28,
    max_pixels=512*28*28
)
print("Model ready!")

PROMPT = """Analyze this image for emergency situations.
Look for: fire, smoke, flooding, illegal garbage dumping, accidents.
Respond ONLY with a valid JSON object, nothing else:
{
  "emergency": true or false,
  "type": "fire" or "flood" or "illegal_garbage" or "accident" or "none",
  "severity": "low" or "medium" or "high" or "none"
}"""

def run_inference(image: Image.Image) -> dict:
    messages = [{"role": "user", "content": [
        {"type": "image", "image": image},
        {"type": "text",  "text": PROMPT}
    ]}]

    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True)
    image_inputs, _ = process_vision_info(messages)
    inputs = processor(
        text=[text], images=image_inputs, return_tensors="pt"
    ).to(model.device)

    with torch.no_grad():
        with torch.autocast(device_type="cuda", dtype=torch.float16):
            output = model.generate(
                **inputs,
                max_new_tokens=100,
                do_sample=False,
                temperature=None,
                top_p=None,
                repetition_penalty=1.0,
                use_cache=True
            )

    raw = processor.decode(output[0], skip_special_tokens=True)
    answer = raw.split("assistant")[-1].strip()

    try:
        start = answer.index("{")
        end   = answer.rindex("}") + 1
        return json.loads(answer[start:end])
    except Exception:
        return {
            "emergency": False,
            "type": "none",
            "severity": "none",
            "raw": answer
        }

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "model": "Qwen2.5-VL-3B-Instruct"})

@app.route("/analyze", methods=["POST"])
def analyze():
    if "image" not in request.files:
        return jsonify({"error": "No image provided. Send as form-data with key 'image'"}), 400

    file = request.files["image"]
    allowed = {".jpg", ".jpeg", ".png", ".webp"}
    ext = "." + file.filename.rsplit(".", 1)[-1].lower()
    if ext not in allowed:
        return jsonify({"error": f"Unsupported format. Allowed: {allowed}"}), 400

    try:
        image = Image.open(io.BytesIO(file.read())).convert("RGB")
    except Exception as e:
        return jsonify({"error": f"Could not open image: {str(e)}"}), 400

    result = run_inference(image)
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
