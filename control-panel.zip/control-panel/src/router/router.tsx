import { createBrowserRouter } from 'react-router-dom';
import { Home } from '../pages/Dashboard';
import { Reports } from '../pages/Reports';
import { ReportDetails } from '../pages/ReportDetails';
import { Drones } from '../pages/Drones';
import { NotFound } from '../pages/NotFound';

export const router = createBrowserRouter([
	{ path: '/', element: <Home /> },
	{ path: 'drones', element: <Drones /> },
	{ path: 'reports/:id', element: <ReportDetails /> },
	{ path: 'reports', element: <Reports /> },
	{ path: '*', element: <NotFound /> },
]);
