import { useState, useCallback } from 'react';
import { useWebSocket } from './useWebSocket';
import type { DroneIncident, WsMessage } from '../utils/types';

const WS_URL = import.meta.env.VITE_WS_URL ?? 'ws://172.20.10.11:3000';

export function useDroneIncidents() {
	const [incidents, setIncidents] = useState<DroneIncident[]>([]);
	const [error, setError] = useState<string | null>(null);
	const [lastUpdate, setLastUpdate] = useState<string | null>(null);

	const handleMessage = useCallback((msg: WsMessage) => {
		if (msg.type === 'drone_incidents') {
			setIncidents((prev) => {
				const existingIds = new Set(prev.map((i) => i.id));
				const fresh = msg.incidents.filter((i) => !existingIds.has(i.id));
				return fresh.length ? [...fresh, ...prev] : prev;
			});
			setLastUpdate(msg.timestamp);
			setError(null);
		} else if (msg.type === 'drone_incidents_error') {
			setError(msg.message);
		}
	}, []);

	const { status } = useWebSocket<WsMessage>({
		url: `${WS_URL}/ws/incidents`,
		onMessage: handleMessage,
	});

	return { incidents, error, lastUpdate, status };
}
