import { useState, useCallback } from 'react';
import { useWebSocket } from './useWebSocket';
import type { DronePosition, WsMessage } from '../utils/types';

const WS_URL = import.meta.env.VITE_WS_URL ?? 'ws://172.20.10.11:3000';

export function useDronePositions() {
	const [positions, setPositions] = useState<DronePosition[]>([]);
	const [error, setError] = useState<string | null>(null);
	const [lastUpdate, setLastUpdate] = useState<string | null>(null);

	const handleMessage = useCallback((msg: WsMessage) => {
		if (msg.type === 'drone_positions') {
			setPositions(msg.positions);
			setLastUpdate(msg.timestamp);
			setError(null);
		} else if (msg.type === 'drone_positions_error') {
			setError(msg.message);
		}
	}, []);

	const { status } = useWebSocket<WsMessage>({
		url: `${WS_URL}/ws/drone-positions`,
		onMessage: handleMessage,
	});

	return { positions, error, lastUpdate, status };
}
