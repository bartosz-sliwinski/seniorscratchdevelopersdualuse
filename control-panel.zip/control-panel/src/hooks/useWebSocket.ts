import { useEffect, useRef, useState } from 'react';

type Status = 'connecting' | 'connected' | 'disconnected' | 'error';

interface Options<T> {
	url: string;
	onMessage: (msg: T) => void;
	reconnectDelay?: number;
	enabled?: boolean;
}

export function useWebSocket<T>({
	url,
	onMessage,
	reconnectDelay = 3000,
	enabled = true,
}: Options<T>) {
	const [status, setStatus] = useState<Status>('connecting');
	const wsRef = useRef<WebSocket | null>(null);
	const onMessageRef = useRef(onMessage);
	const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
	const destroyed = useRef(false);

	useEffect(() => {
		onMessageRef.current = onMessage;
	});

	useEffect(() => {
		if (!enabled) return;

		destroyed.current = false;

		function connect() {
			if (destroyed.current) return;

			const ws = new WebSocket(url);
			wsRef.current = ws;
			setStatus('connecting');

			ws.onopen = () => setStatus('connected');

			ws.onmessage = (event) => {
				try {
					const data: T = JSON.parse(event.data);
					onMessageRef.current(data);
				} catch {
					console.error('[WS] Błąd parsowania:', event.data);
				}
			};

			ws.onerror = () => setStatus('error');

			ws.onclose = () => {
				setStatus('disconnected');
				if (!destroyed.current) {
					reconnectTimer.current = setTimeout(connect, reconnectDelay);
				}
			};
		}

		connect();

		return () => {
			destroyed.current = true;
			if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
			wsRef.current?.close();
		};
	}, [url, reconnectDelay, enabled]);

	return { status };
}
