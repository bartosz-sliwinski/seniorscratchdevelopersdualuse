type Coordinate = [number, number];

export interface Patrol {
	drone_id: string;
	name: string;
	model: string;
	status: string;
	zone: number;
	patrol_mode: string;
	current_index: number;
	current_position: Coordinate;
	route: Coordinate[];
}

export interface Drone {
	drone_id: string;
	name: string;
	model: string;
	status: string;
	zone: number;
}

export interface Silo {
	name: string;
	lat: number;
	lon: number;
}

export interface DronePosition {
	drone_id: string;
	name: string;
	status: string;
	zone: number;
	current_index: number;
	current_position: [number, number];
	battery: number;
}

export interface DroneIncident {
	id: string;
	type: string;
	severity: 'low' | 'medium' | 'high' | 'critical';
	lat: number;
	lon: number;
	timestamp: string;
	image_url: string;
}

export type WsMessage =
	| { type: 'connected'; message: string }
	| {
			type: 'drone_positions';
			source: string;
			positions: DronePosition[];
			timestamp: string;
	  }
	| { type: 'drone_positions_error'; message: string; timestamp: string }
	| { type: 'drone_incidents'; incidents: DroneIncident[]; timestamp: string }
	| { type: 'drone_incidents_error'; message: string; timestamp: string };
