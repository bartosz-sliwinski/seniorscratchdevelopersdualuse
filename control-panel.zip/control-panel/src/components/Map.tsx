import { useEffect, useState } from 'react';
import {
	MapContainer,
	Marker,
	Polygon,
	Polyline,
	Popup,
	TileLayer,
} from 'react-leaflet';
import type { DronePosition, Patrol, Silo } from '../utils/types';
import L from 'leaflet';
import droneGif from '../assets/drone.gif';
import siloPng from '../assets/silo.png';
import { useDronePositions } from '../hooks/useDronePositions';

const droneIcon = L.icon({
	iconUrl: droneGif,
	iconSize: [40, 40],
	iconAnchor: [20, 20],
	popupAnchor: [0, -40],
});

const siloIcon = L.icon({
	iconUrl: siloPng,
	iconSize: [40, 40],
	iconAnchor: [20, 20],
	popupAnchor: [0, -40],
});

export function Map() {
	const [zones, setZones] = useState<[] | null>(null);
	const [patrolRoutes, setPatrolRoutes] = useState<Patrol[] | null>(null);
	const [silos, setSilos] = useState<Silo[] | null>(null);

	const { positions } = useDronePositions();

	useEffect(() => {
		const asyncFunction = async function () {
			await fetch('/zones.json')
				.then((res) => res.json())
				.then((data) => setZones(data?.zones || null));
		};

		asyncFunction();
	}, []);

	useEffect(() => {
		const asyncFunction = async function () {
			await fetch('http://172.20.10.11:3000/api/drone-patrols')
				.then((res) => res.json())
				.then((data) => setPatrolRoutes(data?.patrols || null));
		};

		asyncFunction();
	}, []);

	useEffect(() => {
		const asyncFunction = async function () {
			await fetch('http://172.20.10.11:3000/api/silos')
				.then((res) => res.json())
				.then((data) => setSilos(data?.silos || null));
		};

		asyncFunction();
	}, []);

	return (
		<MapContainer
			center={[50.569306, 22.038852]}
			zoom={12}
			style={{ height: '100%', width: '100%', outline: 'none !important' }}
			maxBounds={[
				[50.4339, 21.8013], // Southwest 15 km
				[50.7047, 22.2764], // Northeast 15 km
			]}
			maxBoundsViscosity={1.0}
			maxZoom={18}
			minZoom={11}
		>
			<TileLayer
				attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
				url='https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'
			/>
			{zones?.map(
				(zone: { id: number; coords: [number, number][] }, index: number) => {
					const purpleOptions = { color: '#6ea8fe' };
					return (
						<Polygon
							key={index}
							pathOptions={purpleOptions}
							positions={zone.coords}
						/>
					);
				},
			)}

			{patrolRoutes?.map((route: Patrol, index: number) => {
				const redOptions = { color: '#ff6756b0' };
				return (
					<Polyline
						key={index}
						pathOptions={redOptions}
						positions={route.route}
					/>
				);
			})}

			{positions.map((drone: DronePosition) => {
				return (
					<Marker
						key={drone.drone_id}
						position={drone.current_position}
						icon={droneIcon}
					>
						<Popup>{drone.battery}%</Popup>
					</Marker>
				);
			})}

			{silos?.map((silo) => {
				return (
					<Marker
						key={silo.name}
						position={[silo.lat, silo.lon]}
						icon={siloIcon}
					></Marker>
				);
			})}
		</MapContainer>
	);
}
