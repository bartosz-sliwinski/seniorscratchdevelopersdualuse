import { Link, useNavigate } from 'react-router-dom';
import { Map } from '../components/Map';
import { useEffect, useState } from 'react';
import type { Drone } from '../utils/types';
import { useDroneIncidents } from '../hooks/useDroneIncidents';

export function Home() {
	const [drones, setDrones] = useState<Drone[] | null>(null);

	const { incidents } = useDroneIncidents();
	const navigate = useNavigate();

	useEffect(() => {
		const asyncFunction = async function () {
			await fetch('http://172.20.10.11:3000/api/drones')
				.then((res) => res.json())
				.then((data) => setDrones(data?.drones || null));
		};

		asyncFunction();
	}, []);

	console.log('Incidents:', incidents);

	return (
		<div className='dashboard dashboard-home'>
			<section className='hero threat-hero'>
				<div className='panel map-panel'>
					<div className='panel-head'>
						<div>
							<p className='panel-kicker'>
								System kontroli przestrzeni powietrznej
							</p>
							<h1>UAVCenter</h1>
						</div>
					</div>

					<div className='image-frame'>
						<Map />
					</div>
				</div>

				<div className='right-split'>
					<div className='panel'>
						<div className='panel-head'>
							<div>
								<p className='panel-kicker'>Monitoring dronów</p>
								<h3>Aktywne drony</h3>
							</div>
							<Link className='back-link' to='/drones'>
								Zobacz wszystkie
							</Link>
						</div>

						<div className='table-wrap'>
							<table>
								<thead>
									<tr>
										<th style={{ width: '40%' }}>Id</th>
										<th style={{ width: '30%' }}>Nazwa</th>
										<th style={{ width: '30%' }}>Status</th>
									</tr>
								</thead>
								<tbody>
									{drones?.map((drone: Drone) => (
										<tr key={drone.drone_id}>
											<td className='code'>{drone.drone_id}</td>
											<td className='type'>{drone.name}</td>
											<td className='type'>{drone.status}</td>
										</tr>
									))}
								</tbody>
							</table>
						</div>
					</div>

					<div className='panel'>
						<div className='panel-head'>
							<div>
								<p className='panel-kicker'>Monitoring zgłoszeń</p>
								<h3>Ostatnie zgłoszenia</h3>
							</div>
							<Link className='back-link' to='/reports'>
								Zobacz wszystkie
							</Link>
						</div>

						<div className='table-wrap'>
							<table>
								<thead>
									<tr>
										<th style={{ width: '33.33%' }}>Data</th>
										<th style={{ width: '33.33%' }}>Typ</th>
										<th style={{ width: '33.33%' }}>Priorytet</th>
									</tr>
								</thead>
								<tbody>
									{incidents?.map((incident) => (
										<tr
											key={incident.id}
											data-clickable='true'
											onClick={() => navigate(`/reports/${incident.id}`)}
											style={{ cursor: 'pointer' }}
										>
											<td className='code'>
												{new Date(incident.timestamp).toLocaleString('pl-PL')}
											</td>
											<td className='type'>
												{[
													'fire',
													'flood',
													'illegal_garbage',
													'accident',
													'none',
												].indexOf(incident.type) !== -1
													? [
															'Pożar',
															'Powódź',
															'Nielegalne odpady',
															'Wypadek',
															'Nieznany',
														][
															[
																'fire',
																'flood',
																'illegal_garbage',
																'accident',
																'none',
															].indexOf(incident.type)
														]
													: incident.type}
											</td>
											<td className='type'>
												{['low', 'medium', 'high'].indexOf(
													incident.severity,
												) !== -1
													? ['Niski', 'Średni', 'Wysoki'][
															['low', 'medium', 'high'].indexOf(
																incident.severity,
															)
														]
													: incident.type}
											</td>
										</tr>
									))}
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
}
