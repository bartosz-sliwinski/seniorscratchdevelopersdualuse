import { Link, useNavigate } from 'react-router-dom';
import { useDroneIncidents } from '../hooks/useDroneIncidents';

export function Reports() {
	const { incidents } = useDroneIncidents();
	const navigate = useNavigate();

	return (
		<div className='dashboard'>
			<div className='panel'>
				<div className='panel-head'>
					<div>
						<p className='panel-kicker'>Monitoring zgłoszeń</p>
						<h1>Zgłoszenia</h1>
					</div>
					<Link className='back-link' to='/'>
						Powrót do panelu
					</Link>
				</div>

				<div className='table-wrap'>
					<table>
						<thead>
							<tr>
								<th style={{ width: '20%' }}>Id</th>
								<th style={{ width: '15%' }}>Typ</th>
								<th style={{ width: '15%' }}>Priorytet</th>
								<th style={{ width: '15%' }}>Lat</th>
								<th style={{ width: '15%' }}>Lon</th>
								<th style={{ width: '20%' }}>Data</th>
							</tr>
						</thead>
						<tbody>
							{incidents?.map((incident) => (
								<tr
									key={incident.id}
									data-clickable='true'
									onClick={() => navigate(`/reports/${incident.id}`)}
									style={{ cursor: 'pointer' }}
								>
									<td className='code'>{incident.id}</td>
									<td className='type'>
										{[
											'fire',
											'flood',
											'illegal_garbage',
											'accident',
											'none',
										].indexOf(incident.type) !== -1
											? [
													'Pożar',
													'Powódź',
													'Nielegalne odpady',
													'Wypadek',
													'Nieznany',
												][
													[
														'fire',
														'flood',
														'illegal_garbage',
														'accident',
														'none',
													].indexOf(incident.type)
												]
											: incident.type}
									</td>
									<td className='type'>
										{['low', 'medium', 'high'].indexOf(incident.severity) !== -1
											? ['Niski', 'Średni', 'Wysoki'][
													['low', 'medium', 'high'].indexOf(incident.severity)
												]
											: incident.type}
									</td>
									<td className='code'>{Number(incident.lat).toFixed(6)}</td>
									<td className='code'>{Number(incident.lon).toFixed(6)}</td>
									<td className='code'>
										{new Date(incident.timestamp).toLocaleString('pl-PL')}
									</td>
								</tr>
							))}
						</tbody>
					</table>
				</div>
			</div>
		</div>
	);
}
