import { Link } from 'react-router-dom';

export function NotFound() {
	return (
		<div className='dashboard'>
			<div className='panel'>
				<div className='panel-head'>
					<div>
						<p className='panel-kicker'>Błąd</p>
						<h1>404 — Strona nie znaleziona</h1>
					</div>
				</div>

				<p className='lede'>
					Wygląda na to, że adres nie istnieje w tym systemie.
				</p>

				<Link className='back-link' to='/'>
					Wróć do panelu głównego
				</Link>
			</div>
		</div>
	);
}
