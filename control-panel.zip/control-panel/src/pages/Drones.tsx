import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import type { Drone } from '../utils/types';

export function Drones() {
	const [drones, setDrones] = useState<Drone[] | null>(null);

	useEffect(() => {
		const asyncFunction = async function () {
			await fetch('http://172.20.10.11:3000/api/drones')
				.then((res) => res.json())
				.then((data) => setDrones(data?.drones || null));
		};

		asyncFunction();
	}, []);

	return (
		<div className='dashboard full-height'>
			<div className='panel full-height-panel'>
				<div className='panel-head'>
					<div>
						<p className='panel-kicker'>Monitoring dronów</p>
						<h1>Drony</h1>
					</div>
					<Link className='back-link' to='/'>
						Powrót do panelu
					</Link>
				</div>

				<div className='table-wrap'>
					<table>
						<thead>
							<tr>
								<th style={{ width: '20%' }}>Id</th>
								<th style={{ width: '20%' }}>Nazwa</th>
								<th style={{ width: '20%' }}>Model</th>
								<th style={{ width: '20%' }}>Status</th>
								<th style={{ width: '20%' }}>Strefa</th>
							</tr>
						</thead>
						<tbody>
							{drones?.map((drone: Drone) => (
								<tr key={drone.drone_id}>
									<td className='code'>{drone.drone_id}</td>
									<td className='type'>{drone.name}</td>
									<td className='type'>{drone.model}</td>
									<td className='type'>{drone.status}</td>
									<td className='type'>{drone.zone}</td>
								</tr>
							))}
						</tbody>
					</table>
				</div>
			</div>
		</div>
	);
}
