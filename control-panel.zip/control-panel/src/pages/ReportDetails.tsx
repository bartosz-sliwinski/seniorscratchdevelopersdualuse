import { useMemo, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { MapContainer, Marker, TileLayer } from 'react-leaflet';
import { useDroneIncidents } from '../hooks/useDroneIncidents';
import './ReportDetails.css';

const typeLabels: Record<string, string> = {
	fire: 'Pożar',
	flood: 'Powódź',
	illegal_garbage: 'Nielegalne odpady',
	accident: 'Wypadek',
	none: 'Nieznany',
};

const severityLabels: Record<string, string> = {
	low: 'Niski',
	medium: 'Średni',
	high: 'Wysoki',
};

const BASE_URL = 'http://172.20.10.11:3000';

export function ReportDetails() {
	const { id } = useParams();
	const navigate = useNavigate();
	const { incidents } = useDroneIncidents();
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [photoModalOpen, setPhotoModalOpen] = useState(false);

	const incident = useMemo(
		() => incidents.find((item) => item.id === id),
		[incidents, id],
	);

	if (!incident) {
		return (
			<div className='dashboard'>
				<div className='panel'>
					<div className='panel-head'>
						<div>
							<p className='panel-kicker'>Szczegóły zgłoszenia</p>
							<h1>Zgłoszenie nie znalezione</h1>
						</div>
						<Link className='back-link' to='/reports'>
							Powrót do listy zgłoszeń
						</Link>
					</div>
					<p className='lede'>
						Wybrane zgłoszenie nie jest dostępne. Wybierz inne zgłoszenie z
						listy.
					</p>
				</div>
			</div>
		);
	}

	const handleReject = async () => {
		setIsLoading(true);
		setError(null);
		try {
			const response = await fetch(
				`${BASE_URL}/api/drone-incidents/${incident.id}`,
				{
					method: 'DELETE',
				},
			);
			if (!response.ok) {
				throw new Error(`Błąd serwera: ${response.status}`);
			}
			navigate('/reports');
		} catch (err) {
			setError(
				err instanceof Error ? err.message : 'Wystąpił nieoczekiwany błąd.',
			);
			setIsLoading(false);
		}
	};

	const handleConfirm = async () => {
		setIsLoading(true);
		setError(null);
		try {
			const response = await fetch(`${BASE_URL}/api/forward-incident`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					drone_incident_id: incident.id,
					type: incident.type,
					severity: incident.severity,
					lat: incident.lat,
					lon: incident.lon,
					timestamp: incident.timestamp,
				}),
			});
			if (!response.ok) {
				throw new Error(`Błąd serwera: ${response.status}`);
			}
			navigate('/reports');
		} catch (err) {
			setError(
				err instanceof Error ? err.message : 'Wystąpił nieoczekiwany błąd.',
			);
			setIsLoading(false);
		}
	};

	const photoUrl = `${BASE_URL}${incident.image_url}?text=${encodeURIComponent(
		`Zdjęcie zgłoszenia ${typeLabels[incident.type] ?? incident.type}`,
	)}`;

	return (
		<div className='dashboard'>
			<div className='panel'>
				<div className='panel-head'>
					<div>
						<p className='panel-kicker'>Szczegóły zgłoszenia</p>
						<h2>Zgłoszenie {incident.id}</h2>
					</div>
					<Link className='back-link' to='/reports'>
						Powrót do listy zgłoszeń
					</Link>
				</div>

				<div className='report-details-grid'>
					<div className='report-details-sidebar'>
						<div className='report-details-meta'>
							<dl>
								<dt>Id</dt>
								<dd>{incident.id}</dd>
								<dt>Typ</dt>
								<dd>{typeLabels[incident.type] ?? incident.type}</dd>
								<dt>Priorytet</dt>
								<dd>
									{severityLabels[incident.severity] ?? incident.severity}
								</dd>
								<dt>Współrzędne</dt>
								<dd>
									{incident.lat.toFixed(6)}, {incident.lon.toFixed(6)}
								</dd>
								<dt>Data</dt>
								<dd>{new Date(incident.timestamp).toLocaleString('pl-PL')}</dd>
							</dl>
						</div>

						<div className='report-details-actions'>
							<button onClick={handleReject} disabled={isLoading}>
								Odrzuć
							</button>
							<button onClick={handleConfirm} disabled={isLoading}>
								Potwierdź
							</button>
						</div>

						{error && <div className='message message--error'>{error}</div>}
					</div>

					<div className='report-details-media'>
						<div className='report-details-map'>
							<MapContainer
								center={[incident.lat, incident.lon]}
								zoom={14}
								style={{ height: '100%', width: '100%' }}
							>
								<TileLayer
									attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
									url='https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'
								/>
								<Marker position={[incident.lat, incident.lon]} />
							</MapContainer>
						</div>
						<div
							className='report-details-image'
							onClick={() => setPhotoModalOpen(true)}
							role='button'
							aria-label='Powiększ zdjęcie zgłoszenia'
						>
							<img src={photoUrl} alt='Zdjęcie zgłoszenia' />
						</div>
					</div>
				</div>
			</div>

			{photoModalOpen && (
				<div className='image-modal' onClick={() => setPhotoModalOpen(false)}>
					<div className='image-modal-inner' role='dialog' aria-modal='true'>
						<button
							className='image-modal-close'
							onClick={(event) => {
								event.stopPropagation();
								setPhotoModalOpen(false);
							}}
						>
							Zamknij
						</button>
						<img src={photoUrl} alt='Powiększone zdjęcie zgłoszenia' />
					</div>
				</div>
			)}
		</div>
	);
}
